#include "arduino.h"

uint16_t g_chipID;

