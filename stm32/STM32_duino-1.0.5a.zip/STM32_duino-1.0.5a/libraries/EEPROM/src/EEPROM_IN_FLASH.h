
uint8_t stm32ReadEEPROM(const int index);
void stm32WriteEEPROM(const int index, uint8_t data);
int stm32GetEEPROMLength();
void stm32FormatEEPROM();
