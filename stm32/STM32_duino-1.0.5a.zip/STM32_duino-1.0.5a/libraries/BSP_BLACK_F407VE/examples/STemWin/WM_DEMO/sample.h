#ifndef _SAMPLE_H
#define _SAMPLE_H

#ifdef __cplusplus
extern "C"{
#endif

void _ShowDemo(void);

#ifdef __cplusplus
}//extern "C"{
#endif

#endif
	
