#ifndef _TEXTDISPLAY_H
#define _TEXTDISPLAY_H


#ifdef __cplusplus
extern "C"{
#endif

void emwin_texttest(void);

#ifdef __cplusplus
}//extern "C"{
#endif

#endif
