
#include "exteeprom.h"
EXTEEPROM  EEPROM;
