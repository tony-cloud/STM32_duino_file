[中文说明](https://github.com/tony-cloud/STM32_duino/blob/master/CHINESE.md)
# STM32GENERIC
Generic implementation of Arduino for STM32 boards using STM32 HAL. This is an alternative to the [Official implementation](https://github.com/stm32duino/Arduino_Core_STM32) 

Documentation: https://danieleff.github.io/STM32GENERIC/

## Installation

~~TODO create boards manager package~~
Now we have a package file for arduino.
Just add https://raw.githubusercontent.com/tony-cloud/STM32BoardManagerFiles/master/STM32/package_tony_stm32_index.json to arduino custom board manager list and then you can find STM32GENERIC in Arduino Board Manager.

